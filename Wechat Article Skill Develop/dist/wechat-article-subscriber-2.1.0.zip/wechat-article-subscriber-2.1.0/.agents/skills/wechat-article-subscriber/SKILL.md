---
name: wechat-article-subscriber
description: Project adapter for configuring, directly ingesting, discovering, reading, evaluating, queueing, exporting, and optionally syncing WeChat Official Account articles. Use when a user sends a WeChat article link or asks for 微信公众号订阅配置、文章发现、批量阅读、评分、推广过滤、待处理队列或飞书多维表格同步 tasks in this repository.
---

# WeChat Article Subscriber

Before acting, read and follow the [canonical Skill instructions](../../../skills/wechat-article-subscriber/SKILL.md) completely.

Use only the canonical implementation under `skills/wechat-article-subscriber/`. Change to that directory before running its platform wrapper. Never create a second implementation under this adapter.
