# Security policy

## Reporting

Report vulnerabilities through a private GitHub security advisory. Do not open a public issue containing credentials, Base identifiers, private article content, or reproduction data copied from a real account.

## Credential model

- WeChat Cookie and token are account-session secrets.
- Agent dialogue is the primary setup path, but the Agent must warn that ordinary chat may be retained, prefer a masked control, obtain consent, collect one value at a time, and never echo it.
- Credentials are passed to the bounded writer through process stdin or a restricted consume-and-delete inbox. Users can instead choose the hidden local terminal fallback.
- Configuration and queue state are stored outside the installed Skill.
- POSIX configuration files are written with user-only permissions; Windows relies on profile ACLs.
- Feishu app secrets must use `lark-cli config init --app-secret-stdin`; they must never be pasted into ordinary chat or process arguments.

If credentials may have been exposed, revoke the browser session, sign in again, and rerun local setup.

## Threat model

The project explicitly defends against:

- Prompt injection in article content.
- SSRF and unsafe redirects from article URLs.
- Unbounded response or context growth.
- Queue corruption and concurrent lost updates.
- Wrong-article writes caused by shifting queue indices.
- Duplicate Feishu records and optimistic sync state.
- Cross-Agent Feishu app/profile confusion, bot impersonation fallback, blind field creation, and retries of non-transient permission errors.
- Secrets in logs or repository files.

Discovery relies on private WeChat browser endpoints. Endpoint changes and platform enforcement are availability risks, not security guarantees.
