# Changelog

## 2.1.0 - Unreleased

### Added

- Add conversational, resumable Feishu setup with optional isolated `lark-cli` installation, explicit `as-user` identity, minimum Base authorization, new/existing Base paths, and app-profile checks.
- Add read-only `feishu-check`, standard schema output, and field-ID mapping for existing user tables.
- Add a redacted offline/online doctor, resumable setup stages, credential health history, per-account discovery diagnostics, and stable JSON command envelopes.
- Add partial dialogue configuration, explicit subscription management/disambiguation, language/preferences, safe Feishu disable, and previewed credential/queue/all-data reset.
- Add custom installation destinations, allowlisted release archives with checksums, tagged GitHub Release automation, and automation safety/retry contracts.
- Add direct WeChat-link ingestion with safe metadata extraction, URL-idempotent queueing, explicit add/skip subscription consent, unknown-publisher recovery, and an explicit per-article Feishu threshold override.
- Add a secret-free `setup --guide` contract, explicit search-window confirmation state, and `manage feishu-context` identity diagnostics.

### Fixed

- Stop automatically creating missing Base fields and stop retrying permission, authorization, mapping, and confirmation errors.
- Upgrade exact-host WeChat API article links to HTTPS before reading.
- Distinguish expired WeChat credentials from incomplete Cookie/wrong-page credential context.
- Force UTF-8 console output on Windows and accept UTF-8 BOM score/config JSON.
- Version configuration migrations and preserve a one-time restricted backup while rejecting unsupported future formats.
- Replace the non-portable deep WeChat token link with a login-first, same-network-request Cookie/token workflow and report which Cookie key names are missing without exposing values.
- Stop guessing the conversational Feishu bot: require a confirmed App ID, distinguish supported Agent binding from existing/dedicated profiles, and optionally pin the authorized user Open ID before table access.

## 2.0.0 - Unreleased

### Security

- Move credential collection to hidden local input and state outside the Skill installation.
- Add strict WeChat article URL and redirect validation, response limits, and untrusted-content delimiters.
- Redact token-bearing request details from errors and logs.

### Fixed

- Add standards-compliant Skill frontmatter and OpenAI Agent metadata.
- Remove duplicate implementations and duplicate tests.
- Repair discovery imports, entrypoint invocation, exception handling, and atomic config updates.
- Replace index-based completion/sync with stable normalized URLs and a retryable sync outbox.
- Use the current `lark-cli` field and record command contracts.
- Correct Feishu score field type and datetime representation.
- Enforce all five score dimensions and configured score thresholds.
- Wire URL normalization, content dedup settings, export, cleanup, batch-read, and sync retry commands.
- Replace global dependency installation with an isolated runtime and recoverable multi-Agent installers.
- Expand CI to compile shipped code, validate release structure, test commands, and smoke-test installers.
- Add platform launchers with `python3`, `python`, and Windows `py -3` fallback.
- Keep `WECHAT_ARTICLE_HOME` consistent between installers and runtime lookup.
- Make installation transactional across Skill targets and dependency setup.
- Quarantine structurally invalid queues and keep every `done --dry-run` path non-mutating.
- Default to URL-authoritative identity and make content-based deduplication opt-in.
- Reject encoded dot-segment and backslash escapes in WeChat article paths.
- Add project-discovery adapters for portable, Claude, and GitHub Copilot repositories.
- Add `--dims-file` examples to avoid PowerShell native-command JSON parsing differences.
- Allow local scoring and completion without a Feishu or WeChat configuration file.
- Make Agent-guided dialogue the primary configuration flow with bounded stdin ingestion, a restricted consume-and-delete inbox fallback, schema validation, redacted confirmation, and a local hidden-input fallback.
