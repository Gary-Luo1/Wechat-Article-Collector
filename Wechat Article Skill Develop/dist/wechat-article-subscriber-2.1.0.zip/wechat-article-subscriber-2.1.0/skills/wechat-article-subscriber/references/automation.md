# Automation contract

Automation is opt-in. Explain the schedule, network activity, credential expiry risk, and whether Feishu writes can occur before creating it. Do not create a schedule merely because setup succeeded.

## Safe unattended boundary

The deterministic unattended action is discovery only:

```text
bash scripts/run.sh discover --format json
```

It fetches configured accounts and updates the local queue. It does not evaluate article content or write Feishu. Article reading/scoring requires an Agent turn because untrusted content must be interpreted under the Skill safety rules. Feishu sync is allowed unattended only after the user has explicitly authorized recurring writes to the named Base/table.

Before scheduling, run:

```text
bash scripts/run.sh manage doctor --online
```

Require `runtime.supported`, installed dependencies, valid WeChat health, resolved subscriptions, and—if enabled—successful Feishu preflight. Store no credentials in the scheduler command or environment; the command reads the restricted application-state config.

## Result handling

- Exit `0` and `ok:true`: record the queue counts; no user notification is needed unless requested.
- WeChat credential/context errors: stop repeated attempts and ask the user to refresh credentials from `/cgi-bin/home`.
- Rate limit/transient errors: use bounded exponential backoff with jitter; do not run more frequently than the configured interval.
- After three consecutive failures recorded in health, suspend the schedule and surface the redacted `doctor` report.
- Never retry authorization, permission, wrong-app, confirmation-required, or field-mapping failures in a loop.

For recurring Feishu sync, preview with `process --format json sync-feishu --all --dry-run`, show the exact destination, obtain explicit recurring-write consent, then use `process --format json sync-feishu --all`. Pending entries remain queued until a confirmed successful write.

To stop automation, disable/delete the scheduler entry first. `manage feishu-disable --yes` stops future Skill sync but does not modify an external scheduler or delete Base data.
