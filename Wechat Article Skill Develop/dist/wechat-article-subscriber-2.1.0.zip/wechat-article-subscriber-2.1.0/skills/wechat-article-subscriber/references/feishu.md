# Feishu dialogue setup

Feishu is optional. Offer: create a new Base, create a table in an existing Base, map an existing table, or skip. Default every Base command to explicit `--as user`; never silently fall back to bot.

## CLI and identity

Run `manage doctor` or `lark-cli --version`. The tested release is `@larksuite/cli@1.0.69`; compatible releases are `>=1.0.69,<2`. If missing, verify Node.js 18+ and npm, explain the package and destination, and obtain permission before installing it locally:

```text
npm install --prefix <APP_STATE>/lark-cli @larksuite/cli@1.0.69
```

The adapter finds the executable under that directory. Do not install globally without explicit permission.

After installation, run `manage feishu-context --verify`. It returns only a
redacted App ID/profile/user snapshot. Display the App ID and authorized user and
ask for explicit confirmation. Never select by bot display name: different apps
can have similar names and a generic Agent cannot reliably prove which Feishu bot
is participating in the current conversation.

Choose exactly one binding mode:

1. `agent`: only when OpenClaw, Hermes, or Lark Channel is detected. After the
   user confirms the App ID and `user-default` identity policy, run
   `lark-cli config bind --source <SOURCE> --app-id <APP_ID> --identity user-default`.
   `--app-id` is required for OpenClaw multi-account selection. Binding changes
   local configuration, so never run it without confirmation.
2. `existing`: use the already configured lark-cli profile only after the user
   confirms its App ID and user shown by `feishu-context`.
3. `dedicated`: recommended for Codex, Claude Code, GitHub Copilot, and other
   generic Agents without a supported binding signal. With confirmation, start
   `lark-cli config init --new`; do not claim this dedicated app is the current
   conversational bot.

Save `binding_mode`, optional `agent_source`, `expected_app_id`, and the confirmed
`expected_user_open_id`. Every Base preflight rejects a missing/mismatched App ID
and, when saved, a mismatched user Open ID before reading or writing the table. If
strict mode blocks user identity, explain the exact policy change and obtain
confirmation. Never request an app secret in ordinary chat; accept one only
through a safe stdin channel.

## Minimum authorization and resume

Request only the Base domain:

```text
lark-cli auth login --domain base --no-wait --json
```

Forward the opaque verification URL unchanged and generate its QR image with
`lark-cli auth qrcode` in the application-state directory. Show both, end the
turn, and wait for the user to confirm authorization; then complete `auth login
--device-code <CODE>`, verify status, and delete the QR image. Keep `device_code`
only in the active authorization flow—never in Skill config, repository files,
or logs. If the link or Agent context expires, discard the QR/code and start a
new minimum-domain flow.

If backend scopes are missing, show the returned console URL and request only the missing scope. A `91403` response means the authenticated user lacks Base access/role permission; fix sharing or role permissions rather than switching identity.

## Provisioning and mapping

Run `process feishu-schema` for the standard schema. Creation and schema extension are external writes: show name, destination, identity, field preview, and dry-run; wait for explicit confirmation before repeating without `--dry-run`.

For an existing Base URL:

1. Resolve it with `base +url-resolve --url <URL> --as user`.
2. If no table is selected, list tables and ask the user to choose.
3. List real fields and map exact/known aliases plus compatible types.
4. Require only `title` and `url`; other mappings are optional.
5. Never treat formula, lookup, system, or attachment fields as ordinary targets.
6. Never create missing fields without a separate schema preview and confirmation.

Known aliases include `标题/文章标题`, `链接/文章链接/URL`, `公众号/公众号名称`, `摘要/文章摘要`, `发布时间/发布日期`, `评分/AI评分`, and `标签/文章标签`. Ambiguous matches require user selection.

Save only the Feishu section with `setup --feishu-agent-stdin` (or the restricted one-time inbox), then run `process feishu-check --save-mapping`. This verifies CLI/app/user/Base/field readiness but remains read-only. Before the first record mutation, show the target and obtain explicit authorization; use a dry-run first.
