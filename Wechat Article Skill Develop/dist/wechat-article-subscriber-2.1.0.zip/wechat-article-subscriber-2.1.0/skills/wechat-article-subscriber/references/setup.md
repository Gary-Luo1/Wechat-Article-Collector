# Installation and WeChat dialogue setup

## Supported environments

- Python 3.9+
- Network access to `mp.weixin.qq.com`
- A local Agent that supports Skills plus shell, filesystem, and network tools
- Optional Feishu: Node.js 18+ and a compatible `@larksuite/cli`

Sandboxed Agents without those capabilities can discover the Skill but cannot execute it. After installation, restart/open the Agent and say “配置微信公众号文章订阅”; configuration is dialogue-first, not a shell wizard.

## Repository installer

```text
bash install.sh --target agents
.\install.ps1 -Target agents
```

Targets: `agents`, `codex`, `claude`, `copilot`, or `all`. For another Agent, install the canonical Skill to an exact folder:

```text
bash install.sh --target agents --destination /custom/skills/wechat-article-subscriber
.\install.ps1 -Target agents -InstallPath C:\custom\skills\wechat-article-subscriber
```

Do not combine a custom destination with `all`. The installer atomically backs up an existing copy, installs only canonical files, and creates an isolated runtime in application state. `WECHAT_SKILL_INSTALL_ROOT` remains available for CI. `--no-deps` / `-NoDeps` requires `requests` and `beautifulsoup4` in the selected runtime.

## Secret transport capability matrix

| Agent capability | Method | Rule |
|---|---|---|
| Masked/secret input + process stdin | `setup --agent-stdin` | Preferred |
| Filesystem API but no stdin | `setup --prepare-agent-file`, write exact inbox, then `setup --agent-file` | Inbox is restricted and consumed once |
| Neither safe channel | Local hidden-input `setup` | User enters secrets in terminal |

Never put Cookie/token in command arguments, environment variables, repository files, arbitrary temporary files, logs, or responses. Before ordinary chat input, explain retention risk and obtain consent. Ask one field at a time and never quote it back.

## WeChat setup

Start by running `setup --guide --format json`. Tell the user exactly where each
answer goes:

- Preferred: the current Agent's masked/secret input control.
- Ordinary chat: only after warning that messages may be retained and obtaining
  explicit consent; ask Cookie and token separately.
- Fallback: run local `setup` and enter secrets at its hidden prompts.

Do not send users to a deep `cgi-bin/home` link; it may not open before a valid
session exists. Instead:

1. Open `https://mp.weixin.qq.com/` and sign in.
2. Open browser developer tools (`F12`) → Network and refresh the page.
3. Select an authenticated request whose path starts with `/cgi-bin/`.
4. Copy the **complete Cookie Request Header**, not a hand-built subset.
5. Copy the numeric `token` Query String parameter from that same request.

Never accept a token from `/wxamp/`. The Cookie commonly contains the diagnostic
keys `rand_info` and `slave_bizuin`; session keys can include `slave_sid`,
`slave_user`, `bizuin`/`data_bizuin`, and `data_ticket`. These names are a
checklist, not permission to copy only those fields. Display names only, never
Cookie values.

Then ask for exact subscribed account names and a required search window:
“每次希望搜索多久以内的文章？24 小时（推荐）、48 小时、7 天，还是自定义？”
If the user skips it, explicitly say that 24 hours will be used; never apply the
default silently. Values above 48 hours with a per-account result limit of 10 or
less may miss articles on busy accounts, so warn and offer to raise the limit.

Build the full payload in memory and send it over the selected safe channel:

```json
{
  "wechat_cookie": "<secret>",
  "wechat_token": "<secret>",
  "subscriptions": ["Exact Account", {"name":"Another","alias":"optional"}],
  "settings": {"check_hours":24,"output_language":"auto"},
  "feishu": {"enabled": false}
}
```

Then validate and resolve:

```text
discover --check-token --format json
discover --resolve-subscriptions --format json
```

Show candidates for ambiguous accounts and save only explicit/exact choices with `--save-resolved`. Credentials can be very short-lived; validate immediately after capture. Distinguish expired session (refresh both values) from wrong context/incomplete Cookie (repeat the same-request Network extraction).

Use partial setup sections later so the user does not re-enter unrelated values. See [operations.md](operations.md). For optional Base creation/mapping and user authorization, read [feishu.md](feishu.md). For credential safety and article prompt-injection boundaries, read [security.md](security.md).

## Local state

- Windows: `%APPDATA%\wechat-article-subscriber`
- macOS: `~/Library/Application Support/wechat-article-subscriber`
- Linux: `$XDG_STATE_HOME/wechat-article-subscriber` or `~/.local/state/wechat-article-subscriber`
- Override: `WECHAT_ARTICLE_HOME`

Run `manage doctor` for resumable setup state and `manage reset` for explicit previewed cleanup.
