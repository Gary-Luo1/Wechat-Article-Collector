# Operations and recovery

Use the management command as the first diagnostic boundary. It emits a stable JSON envelope and never returns Cookie, token, Base token, or table ID.

```text
bash scripts/run.sh manage doctor
bash scripts/run.sh manage doctor --online
bash scripts/run.sh manage config-show
```

`doctor` reports runtime/dependency availability, redacted configuration, queue counts, lark-cli compatibility, health history, `setup_stage`, and `next_action`. Offline mode performs no network calls. Online mode validates WeChat, resolves subscription candidates, and runs the read-only Feishu preflight when enabled. Add `--save-resolved` only after exact results have been shown or confirmed.

## Partial dialogue configuration

The Agent may patch one section without asking the user to repeat unrelated values:

```text
setup --agent-stdin --section wechat
setup --agent-stdin --section subscriptions
setup --agent-stdin --section settings
setup --agent-stdin --section feishu
```

Accepted settings include `check_hours`, `request_delay`, `max_articles_per_account`, `content_dedup`, `min_score`, and `output_language` (`auto`, `zh`, or `en`). Ask for preferences in dialogue; do not require users to edit JSON.

Subscription maintenance is local and explicit:

```text
manage subscriptions list
manage subscriptions add --name <EXACT_NAME>
manage subscriptions remove <NAME_OR_ALIAS_OR_BIZ>
discover --resolve-subscriptions --format json
discover --resolve-subscriptions --save-resolved --format json
```

Ambiguous search results require user choice. A missing result is not silently removed.

## Direct-link ingestion

```text
process --format json ingest --url <WECHAT_URL>
```

The command safely extracts the article title, publisher, publication time, digest, and bounded body. It does not place the body in the queue. If the publisher is absent from subscriptions, it returns `SUBSCRIPTION_CONFIRMATION_REQUIRED` before changing either config or queue. Ask the user, then run exactly one:

```text
process --format json ingest --url <WECHAT_URL> --subscribe
process --format json ingest --url <WECHAT_URL> --no-subscribe
```

When page metadata has no publisher, collect the name from the user and add `--account <NAME>`. `--subscribe` is authorization to modify the local subscription list; never use it speculatively. `--no-subscribe` queues the article once. Repeated ingestion is URL-idempotent.

After ingestion, use the existing `read` and `done` workflow. For an explicit user request to write this individual article regardless of its score, combine `--feishu --force-feishu`. `--force-feishu` is invalid without `--feishu` and does not change the saved score threshold.

## Safe disable and reset

All destructive reset commands preview targets unless `--yes` is supplied:

```text
manage feishu-disable
manage feishu-disable --yes
manage reset --scope credentials
manage reset --scope credentials --yes
manage reset --scope queue
manage reset --scope queue --yes
manage reset --scope all-data
manage reset --scope all-data --yes
```

Credential reset preserves subscriptions, settings, and queue. Queue reset removes only the queue and its lock. All-data reset removes the local config, queue, lock, and versioned config backups; it does not delete the isolated runtime, installed Skill, WeChat data, or Feishu Base data. Deleted all-data state is not recoverable by the Skill.

## Stable command protocol

Machine-readable commands return one JSON object:

```json
{"ok":true,"data":{},"next_action":"none"}
```

Failures use `error.code`, a redacted `message`, `retryable`, and `next_action`. Agents should branch on the code, not parse human prose. `process` accepts global formatting before the subcommand: `process --format json list`.

Configuration format changes are versioned. The first migration preserves a restricted `config.vN.backup.json`; `manage reset --scope all-data --yes` removes these backups too.
