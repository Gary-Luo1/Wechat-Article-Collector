#!/usr/bin/env python3
"""Inspect, patch, diagnose, and safely reset skill state."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import platform
import sys
from pathlib import Path
from typing import Any

from bitable_client import (
    LarkCLIError,
    feishu_identity_context,
    lark_cli_info,
    preflight_feishu,
)
from config_store import (
    DEFAULT_CONFIG,
    ConfigError,
    load_config,
    redacted_config,
    save_config,
    update_health,
    validate_config,
)
from paths import config_path, data_dir, lock_path, queue_path, venv_dir
from protocol import dump, failure, success
from queue_helpers import read_queue


def _next_stage(config: dict[str, Any], *, cli: dict[str, Any] | None = None) -> tuple[str, str]:
    if not config["wechat"]["cookie"].strip() or not config["wechat"]["token"].strip():
        return "wechat_credentials_missing", "configure_wechat_in_dialogue"
    if not config["health"]["wechat"]["last_verified_at"]:
        return "wechat_unverified", "run_online_doctor"
    if not config["setup"]["search_window_confirmed"]:
        return "search_window_unconfirmed", "ask_user_for_search_window"
    if not config["subscriptions"]:
        return "subscriptions_missing", "ask_for_subscription_names"
    if any(not str(item.get("biz", "")).strip() for item in config["subscriptions"]):
        return "subscriptions_unresolved", "resolve_and_confirm_subscriptions"
    if not config["feishu"]["enabled"]:
        return "ready_wechat_only", "discover_articles"
    if cli is None:
        return "feishu_cli_missing_or_unchecked", "check_or_install_lark_cli"
    if not cli.get("compatible"):
        return "feishu_cli_incompatible", "install_compatible_lark_cli"
    if not config["health"]["feishu"]["last_verified_at"]:
        return "feishu_unverified", "authorize_and_run_feishu_check"
    return "ready", "discover_articles"


def _doctor(*, online: bool, save_resolved: bool) -> tuple[dict[str, Any], str]:
    report: dict[str, Any] = {
        "runtime": {
            "python": platform.python_version(),
            "supported": sys.version_info >= (3, 9),
            "dependencies": {
                name: importlib.util.find_spec(name) is not None
                for name in ("requests", "bs4")
            },
        },
        "paths": {
            "data_dir": str(data_dir()),
            "config": str(config_path()),
            "queue": str(queue_path()),
            "venv": str(venv_dir()),
        },
        "transport": {
            "recommended": "agent writes one-time inbox or passes stdin",
            "stdin_supported": True,
            "one_time_inbox_supported": True,
            "command_line_secrets_supported": False,
        },
    }
    try:
        config = load_config()
    except ConfigError:
        report["config"] = {"exists": False}
        report["setup_stage"] = "config_missing"
        return report, "configure_wechat_in_dialogue"

    report["config"] = {"exists": True, **redacted_config(config)}
    report["warnings"] = []
    if (
        config["settings"]["check_hours"] > 48
        and config["settings"]["max_articles_per_account"] <= 10
    ):
        report["warnings"].append(
            {
                "kind": "search_window_coverage",
                "message": (
                    "The lookback window exceeds 48 hours while the per-account limit is "
                    "10 or lower; busy accounts may not be covered completely."
                ),
                "next_action": "increase_max_articles_per_account_or_reduce_search_window",
            }
        )
    queue = read_queue()
    report["queue"] = {
        "total": len(queue["pending"]) + len(queue["processed"]),
        "pending": len(queue["pending"]),
        "processed": len(queue["processed"]),
        "sync_pending": sum(
            item.get("sync_status") == "pending"
            for item in queue["processed"].values()
        ),
    }
    cli: dict[str, Any] | None = None
    try:
        cli = lark_cli_info()
        report["lark_cli"] = cli
    except LarkCLIError as exc:
        report["lark_cli"] = {
            "available": False,
            "error_kind": exc.kind,
            "message": str(exc),
        }

    online_report: dict[str, Any] = {}
    if online:
        try:
            from discover_only import resolve_subscriptions
            from wechat_api import WeChatAPI

            api = WeChatAPI(
                config["wechat"]["cookie"],
                config["wechat"]["token"],
                request_delay=config["settings"]["request_delay"],
            )
            api.search_account("微信", begin=0, count=1)
            config = update_health("wechat", success=True)
            online_report["wechat"] = {"ok": True}
            resolutions = resolve_subscriptions(
                config,
                api=api,
                save=save_resolved,
            )
            unresolved = sum(item["status"] not in {"resolved", "exact"} for item in resolutions)
            online_report["subscriptions"] = {
                "ok": unresolved == 0,
                "unresolved": unresolved,
                "results": resolutions,
            }
        except Exception as exc:  # classified and redacted by the protocol layer
            try:
                update_health("wechat", success=False, failure_kind=type(exc).__name__)
            except Exception:
                pass
            online_report["wechat"] = failure(exc)["error"]

        if config["feishu"]["enabled"]:
            try:
                result = preflight_feishu(config["feishu"])
                update_health("feishu", success=True)
                online_report["feishu"] = {"ok": True, "preflight": result}
            except Exception as exc:
                try:
                    update_health("feishu", success=False, failure_kind=getattr(exc, "kind", type(exc).__name__))
                except Exception:
                    pass
                online_report["feishu"] = failure(exc)["error"]
        report["online"] = online_report

    config = load_config()
    stage, next_action = _next_stage(config, cli=cli)
    report["setup_stage"] = stage
    report["health"] = config["health"]
    return report, next_action


def _detect_agent_source() -> str:
    signals = {
        "openclaw": ("OPENCLAW_HOME", "OPENCLAW_STATE_DIR", "OPENCLAW_GATEWAY_TOKEN"),
        "hermes": ("HERMES_HOME", "HERMES_STATE_DIR"),
        "lark-channel": ("LARK_CHANNEL", "LARK_CHANNEL_HOME", "LARK_CHANNEL_APP_ID"),
    }
    for source, names in signals.items():
        if any(os.environ.get(name) for name in names):
            return source
    return ""


def _feishu_context(*, verify: bool) -> tuple[dict[str, Any], str]:
    context = feishu_identity_context(verify=verify)
    source = _detect_agent_source()
    current = load_config()
    saved_source = str(current["feishu"].get("agent_source") or "")
    can_bind = source in {"openclaw", "hermes", "lark-channel"}
    context.update(
        {
            "agent_source_detected": source,
            "agent_source_configured": saved_source,
            "can_bind_current_agent": can_bind,
            "selection_rule": (
                "Confirm the App ID and authorized user shown here. Never select by bot "
                "display name alone."
            ),
            "binding_modes": {
                "agent": (
                    "Bind the detected OpenClaw/Hermes/Lark Channel app after explicit "
                    "confirmation."
                    if can_bind
                    else "Unavailable: this Agent does not expose a supported app binding source."
                ),
                "existing": "Use and explicitly confirm the existing lark-cli App ID/profile.",
                "dedicated": (
                    "Initialize a dedicated Feishu app/profile; recommended for generic "
                    "Agents that cannot prove the conversational bot identity."
                ),
            },
        }
    )
    if not context["app_id_unambiguous"]:
        return context, "select_or_initialize_feishu_profile"
    if not context["user"]["available"] or context["user"]["status"] != "ready":
        return context, "authorize_user_for_base"
    return context, "confirm_feishu_app_and_user"


def _subscriptions(arguments: argparse.Namespace) -> dict[str, Any]:
    config = load_config()
    items = config["subscriptions"]
    if arguments.subscription_command == "list":
        return {"subscriptions": items}
    if arguments.subscription_command == "add":
        candidate = {
            key: value.strip()
            for key, value in {"name": arguments.name, "alias": arguments.alias, "biz": arguments.biz}.items()
            if value and value.strip()
        }
        if not candidate:
            raise ValueError("provide --name, --alias, or --biz")
        identity = {str(candidate.get(key, "")).casefold() for key in ("name", "alias", "biz") if candidate.get(key)}
        for existing in items:
            existing_identity = {str(existing.get(key, "")).casefold() for key in ("name", "alias", "biz") if existing.get(key)}
            if identity & existing_identity:
                raise ValueError("subscription already exists")
        items.append(candidate)
        save_config(config)
        return {"added": candidate, "count": len(items)}
    selector = arguments.value.casefold()
    retained = [
        item
        for item in items
        if selector not in {
            str(item.get(key, "")).casefold() for key in ("name", "alias", "biz")
        }
    ]
    removed = len(items) - len(retained)
    if not removed:
        raise LookupError("subscription not found")
    config["subscriptions"] = retained
    save_config(config)
    return {"removed": removed, "count": len(retained)}


def _reset(arguments: argparse.Namespace) -> tuple[dict[str, Any], str]:
    scope = arguments.scope
    targets: list[Path] = []
    if scope in {"queue", "all-data"}:
        targets.extend([queue_path(), lock_path()])
    if scope == "all-data":
        targets.append(config_path())
        targets.extend(config_path().parent.glob("config.v*.backup.json"))
    existing = sorted({path.resolve() for path in targets if path.exists()}, key=str)
    if not arguments.yes:
        return {"preview": [str(path) for path in existing], "deleted": []}, "rerun_with_yes"
    if scope == "credentials":
        config = load_config()
        config["wechat"] = {"cookie": "", "token": ""}
        config["feishu"].update({
            "enabled": False,
            "binding_mode": "",
            "agent_source": "",
            "expected_app_id": "",
            "expected_user_open_id": "",
            "base_token": "",
            "table_id": "",
            "field_mapping": {},
            "provisioning": "",
        })
        config["health"] = validate_config(DEFAULT_CONFIG)["health"]
        save_config(config)
        return {"cleared": "credentials", "preserved": ["subscriptions", "settings", "queue"]}, "configure_wechat_in_dialogue"
    for target in existing:
        target.unlink()
    return {"deleted": [str(path) for path in existing], "recoverable": False}, "none"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--format", choices=("json", "text"), default="json")
    commands = parser.add_subparsers(dest="command", required=True)
    doctor = commands.add_parser("doctor")
    doctor.add_argument("--online", action="store_true")
    doctor.add_argument("--save-resolved", action="store_true")
    commands.add_parser("config-show")
    context = commands.add_parser("feishu-context")
    context.add_argument("--verify", action="store_true")
    subs = commands.add_parser("subscriptions")
    subcommands = subs.add_subparsers(dest="subscription_command", required=True)
    subcommands.add_parser("list")
    add = subcommands.add_parser("add")
    add.add_argument("--name", default="")
    add.add_argument("--alias", default="")
    add.add_argument("--biz", default="")
    remove = subcommands.add_parser("remove")
    remove.add_argument("value")
    disable = commands.add_parser("feishu-disable")
    disable.add_argument("--yes", action="store_true")
    reset = commands.add_parser("reset")
    reset.add_argument("--scope", choices=("credentials", "queue", "all-data"), required=True)
    reset.add_argument("--yes", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    try:
        next_action = "none"
        if arguments.command == "doctor":
            data, next_action = _doctor(online=arguments.online, save_resolved=arguments.save_resolved)
        elif arguments.command == "config-show":
            data = redacted_config(load_config())
        elif arguments.command == "feishu-context":
            data, next_action = _feishu_context(verify=arguments.verify)
        elif arguments.command == "subscriptions":
            data = _subscriptions(arguments)
        elif arguments.command == "feishu-disable":
            if not arguments.yes:
                data, next_action = {"preview": "disable Feishu sync; no Base data is deleted"}, "rerun_with_yes"
            else:
                config = load_config()
                config["feishu"]["enabled"] = False
                save_config(config)
                data = {"disabled": True, "base_data_deleted": False}
        else:
            data, next_action = _reset(arguments)
        envelope = success(data, next_action=next_action)
        print(dump(envelope) if arguments.format == "json" else json.dumps(envelope, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        envelope = failure(exc)
        print(dump(envelope) if arguments.format == "json" else json.dumps(envelope, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
