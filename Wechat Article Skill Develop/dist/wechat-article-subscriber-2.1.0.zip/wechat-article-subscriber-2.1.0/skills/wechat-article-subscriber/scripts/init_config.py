#!/usr/bin/env python3
"""Validate and persist configuration from Agent stdin or a local wizard."""

from __future__ import annotations

import argparse
from copy import deepcopy
import getpass
import json
import logging
import os
from pathlib import Path
import stat
import sys
import tempfile
from typing import Any

from config_store import (
    DEFAULT_CONFIG,
    LEGACY_FIELD_MAPPING,
    ConfigError,
    load_config,
    save_config,
    validate_config,
)
from paths import data_dir
from protocol import dump, failure, success


MAX_AGENT_INPUT_BYTES = 256 * 1024
AGENT_INPUT_KEYS = {
    "wechat_cookie",
    "wechat_token",
    "subscriptions",
    "feishu_base_token",
    "feishu_table_id",
    "feishu",
    "settings",
}

FEISHU_INPUT_KEYS = {
    "enabled",
    "identity",
    "binding_mode",
    "agent_source",
    "expected_app_id",
    "expected_user_open_id",
    "base_token",
    "table_id",
    "provisioning",
    "schema_policy",
    "field_mapping",
}
RECOMMENDED_COOKIE_KEYS = {"rand_info", "slave_bizuin"}
SESSION_COOKIE_KEYS = {
    "bizuin",
    "data_bizuin",
    "data_ticket",
    "slave_sid",
    "slave_user",
}
SETTINGS_INPUT_KEYS = {
    "check_hours",
    "request_delay",
    "max_articles_per_account",
    "content_dedup",
    "min_score",
    "output_language",
}


def _required_string(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"{key} must be a non-empty string")
    return value.strip()


def _optional_string(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key, "")
    if not isinstance(value, str):
        raise ConfigError(f"{key} must be a string")
    return value.strip()


def _normalize_subscriptions(value: Any) -> list[dict[str, str]]:
    if not isinstance(value, list) or not value:
        raise ConfigError("subscriptions must be a non-empty list")
    if len(value) > 100:
        raise ConfigError("subscriptions cannot contain more than 100 accounts")
    normalized: list[dict[str, str]] = []
    seen: set[tuple[str, str, str]] = set()
    for index, item in enumerate(value):
        if isinstance(item, str):
            subscription = {"name": item.strip(), "alias": "", "biz": ""}
        elif isinstance(item, dict):
            unexpected = set(item) - {"name", "alias", "biz"}
            if unexpected:
                raise ConfigError(
                    f"subscriptions[{index}] contains unsupported keys: {sorted(unexpected)}"
                )
            subscription = {}
            for key in ("name", "alias", "biz"):
                raw = item.get(key, "")
                if not isinstance(raw, str):
                    raise ConfigError(f"subscriptions[{index}].{key} must be a string")
                subscription[key] = raw.strip()
        else:
            raise ConfigError(f"subscriptions[{index}] must be a name or object")
        identity = tuple(subscription[key].casefold() for key in ("name", "alias", "biz"))
        if not any(identity):
            raise ConfigError(f"subscriptions[{index}] needs name, alias, or biz")
        if identity not in seen:
            normalized.append(subscription)
            seen.add(identity)
    return normalized


def _cookie_names(cookie: str) -> set[str]:
    names: set[str] = set()
    for part in cookie.split(";"):
        name, separator, _ = part.partition("=")
        if separator and name.strip():
            names.add(name.strip())
    return names


def _warn_credential_shape(cookie: str, token: str) -> None:
    missing = sorted(RECOMMENDED_COOKIE_KEYS - _cookie_names(cookie))
    if missing:
        logging.warning(
            "WeChat Cookie is missing commonly required keys (%s). Copy the complete "
            "Cookie request header from the same authenticated /cgi-bin/ network "
            "request as the token.",
            ", ".join(missing),
        )
    if not token.isdigit():
        logging.warning(
            "WeChat token has an unexpected shape. After signing in at "
            "https://mp.weixin.qq.com/, copy the numeric token query parameter from "
            "the same authenticated /cgi-bin/ network request as the Cookie, not /wxamp/."
        )


def credential_shape(cookie: str, token: str) -> dict[str, Any]:
    """Return a value-free diagnostic safe to include in Agent output."""
    names = _cookie_names(cookie)
    return {
        "complete_cookie_requested": True,
        "missing_diagnostic_keys": sorted(RECOMMENDED_COOKIE_KEYS - names),
        "present_session_key_names": sorted(SESSION_COOKIE_KEYS & names),
        "token_is_numeric": token.isdigit(),
        "values_echoed": False,
    }


def setup_guide() -> dict[str, Any]:
    """Return deterministic, secret-free setup instructions for any Agent UI."""
    return {
        "input_location": {
            "preferred": "the current Agent's masked or secret input control",
            "ordinary_chat": (
                "only after warning that the platform may retain messages and obtaining "
                "explicit consent; ask one secret at a time"
            ),
            "fallback": "run setup locally and enter values at the hidden prompts",
            "never": ["command-line arguments", "environment variables", "repository files"],
        },
        "wechat_credentials": {
            "login_url": "https://mp.weixin.qq.com/",
            "steps": [
                "Sign in to the Official Accounts Platform at the login URL.",
                "Open browser developer tools, choose Network, and refresh the page.",
                "Select an authenticated request whose path starts with /cgi-bin/.",
                "Copy the complete Cookie value from Request Headers.",
                "Copy the numeric token query parameter from that same request.",
            ],
            "cookie_rule": "copy the complete Cookie header; do not assemble selected keys",
            "cookie_diagnostic_keys": sorted(RECOMMENDED_COOKIE_KEYS),
            "cookie_session_checklist": sorted(SESSION_COOKIE_KEYS),
            "token_rule": "use the same /cgi-bin/ request; never use a /wxamp/ token",
        },
        "search_window": {
            "required_question": "每次希望搜索多久以内的文章？",
            "choices": [
                {"label": "24 小时（推荐）", "hours": 24},
                {"label": "48 小时", "hours": 48},
                {"label": "7 天", "hours": 168},
                {"label": "自定义", "hours": None},
            ],
            "default_if_skipped": 24,
            "rule": "state the 24-hour default explicitly; never apply it silently",
        },
    }


def _normalize_feishu(value: Any) -> dict[str, Any]:
    if value is None:
        return deepcopy(DEFAULT_CONFIG["feishu"])
    if not isinstance(value, dict):
        raise ConfigError("feishu must be an object")
    unexpected = set(value) - FEISHU_INPUT_KEYS
    if unexpected:
        raise ConfigError(f"feishu contains unsupported keys: {sorted(unexpected)}")
    normalized = deepcopy(DEFAULT_CONFIG["feishu"])
    normalized.update(value)
    # Supplying a complete target means sync is intentionally enabled unless
    # the Agent explicitly sends enabled=false.
    if "enabled" not in value and normalized.get("base_token") and normalized.get("table_id"):
        normalized["enabled"] = True
    return normalized


def config_from_agent_payload(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise ConfigError("Agent configuration must be a JSON object")
    unexpected = set(payload) - AGENT_INPUT_KEYS
    if unexpected:
        raise ConfigError(f"Agent configuration contains unsupported keys: {sorted(unexpected)}")
    if "feishu" in payload and (
        "feishu_base_token" in payload or "feishu_table_id" in payload
    ):
        raise ConfigError("use feishu or legacy Feishu fields, not both")
    if "feishu" in payload:
        feishu = _normalize_feishu(payload["feishu"])
    else:
        base_token = _optional_string(payload, "feishu_base_token")
        table_id = _optional_string(payload, "feishu_table_id")
        if bool(base_token) != bool(table_id):
            raise ConfigError("provide both Feishu Base token and table ID, or leave both empty")
        feishu = deepcopy(DEFAULT_CONFIG["feishu"])
        if base_token and table_id:
            feishu.update(
                {
                    "enabled": True,
                    "base_token": base_token,
                    "table_id": table_id,
                    "provisioning": "existing",
                    "field_mapping": deepcopy(LEGACY_FIELD_MAPPING),
                }
            )
    cookie = _required_string(payload, "wechat_cookie")
    token = _required_string(payload, "wechat_token")
    _warn_credential_shape(cookie, token)
    config = deepcopy(DEFAULT_CONFIG)
    config["wechat"] = {
        "cookie": cookie,
        "token": token,
    }
    config["subscriptions"] = _normalize_subscriptions(payload.get("subscriptions"))
    config["feishu"] = feishu
    if "settings" in payload:
        config["settings"] = _normalize_settings(payload["settings"], partial=True)
        config["setup"]["search_window_confirmed"] = (
            "check_hours" in payload["settings"]
        )
    return validate_config(config, require_wechat=True)


def config_from_feishu_payload(payload: Any) -> dict[str, Any]:
    config = load_config(require_wechat=True)
    config["feishu"] = _normalize_feishu(payload)
    return validate_config(config, require_wechat=True)


def _normalize_settings(value: Any, *, partial: bool) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ConfigError("settings must be an object")
    unexpected = set(value) - SETTINGS_INPUT_KEYS
    if unexpected:
        raise ConfigError(f"settings contains unsupported keys: {sorted(unexpected)}")
    normalized = deepcopy(DEFAULT_CONFIG["settings"])
    if partial:
        normalized.update(value)
    else:
        normalized = dict(value)
    return normalized


def config_from_section_payload(section: str, payload: Any) -> dict[str, Any]:
    if section == "full":
        return config_from_agent_payload(payload)
    config = load_config(require_wechat=True)
    if section == "feishu":
        config["feishu"] = _normalize_feishu(payload)
    elif section == "wechat":
        if not isinstance(payload, dict):
            raise ConfigError("wechat credential update must be an object")
        unexpected = set(payload) - {"wechat_cookie", "wechat_token"}
        if unexpected:
            raise ConfigError(f"wechat update contains unsupported keys: {sorted(unexpected)}")
        cookie = _required_string(payload, "wechat_cookie")
        token = _required_string(payload, "wechat_token")
        _warn_credential_shape(cookie, token)
        config["wechat"] = {"cookie": cookie, "token": token}
        config["health"]["wechat"] = deepcopy(DEFAULT_CONFIG["health"]["wechat"])
    elif section == "subscriptions":
        value = payload.get("subscriptions") if isinstance(payload, dict) else payload
        config["subscriptions"] = _normalize_subscriptions(value)
        config["health"]["subscriptions"] = deepcopy(
            DEFAULT_CONFIG["health"]["subscriptions"]
        )
    elif section == "settings":
        if not isinstance(payload, dict):
            raise ConfigError("settings must be an object")
        unexpected = set(payload) - SETTINGS_INPUT_KEYS
        if unexpected:
            raise ConfigError(f"settings contains unsupported keys: {sorted(unexpected)}")
        updates = dict(payload)
        config["settings"].update(updates)
        if "check_hours" in updates:
            config["setup"]["search_window_confirmed"] = True
    else:
        raise ConfigError(f"unsupported setup section: {section}")
    return validate_config(config, require_wechat=True)


def _save_agent_raw(raw: str, *, section: str = "full", json_output: bool = False) -> int:
    if len(raw.encode("utf-8")) > MAX_AGENT_INPUT_BYTES:
        logging.error("Agent configuration exceeds the input size limit")
        return 1
    try:
        payload = json.loads(raw.lstrip("\ufeff"))
        config = config_from_section_payload(section, payload)
        path = save_config(config)
    except (ConfigError, OSError, json.JSONDecodeError, UnicodeError) as exc:
        if json_output:
            print(dump(failure(exc)))
        else:
            logging.error("Cannot save Agent configuration: %s", exc)
        return 1
    result = {
        "path": str(path),
        "section": section,
        "subscriptions": len(config["subscriptions"]),
        "feishu_enabled": config["feishu"]["enabled"],
        "search_window_hours": config["settings"]["check_hours"],
        "search_window_confirmed": config["setup"]["search_window_confirmed"],
        "credentials_echoed": False,
    }
    if section in {"full", "wechat"}:
        result["wechat_credential_check"] = credential_shape(
            config["wechat"]["cookie"], config["wechat"]["token"]
        )
    next_action = (
        "run_doctor_online"
        if config["setup"]["search_window_confirmed"]
        else "ask_user_for_search_window"
    )
    if json_output:
        print(dump(success(result, next_action=next_action)))
        return 0
    print(f"Configuration saved with restricted permissions: {path}")
    print(
        f"Configured {len(config['subscriptions'])} subscription(s); "
        f"Feishu sync {'enabled' if config['feishu']['enabled'] else 'disabled'}."
    )
    print("Credential values were not echoed.")
    if not config["setup"]["search_window_confirmed"]:
        print(
            "Search window is not confirmed. Ask for 24 hours (recommended), "
            "48 hours, 7 days, or a custom value before continuing."
        )
    return 0


def _agent_stdin_setup(*, section: str = "full", json_output: bool = False) -> int:
    if sys.stdin.isatty():
        exc = ValueError("--agent-stdin requires a JSON document on standard input")
        print(dump(failure(exc))) if json_output else logging.error("%s", exc)
        return 1
    return _save_agent_raw(
        sys.stdin.read(MAX_AGENT_INPUT_BYTES + 1),
        section=section,
        json_output=json_output,
    )


def _prepare_agent_file(*, json_output: bool = False) -> int:
    root = data_dir()
    try:
        root.mkdir(parents=True, exist_ok=True)
        descriptor, name = tempfile.mkstemp(
            prefix=".agent-config-",
            suffix=".json",
            dir=root,
        )
        try:
            if os.name != "nt":
                os.fchmod(descriptor, stat.S_IRUSR | stat.S_IWUSR)
        finally:
            os.close(descriptor)
    except OSError as exc:
        print(dump(failure(exc, message="cannot prepare Agent configuration inbox"))) if json_output else logging.error("Cannot prepare Agent configuration inbox: %s", exc)
        return 1
    path = str(Path(name).resolve())
    print(dump(success({"inbox_path": path})) if json_output else path)
    return 0


def _scoped_agent_file(value: Path) -> Path:
    candidate = Path(value).expanduser()
    if candidate.is_symlink():
        raise ConfigError("Agent configuration inbox cannot be a symbolic link")
    resolved = candidate.resolve()
    root = data_dir().resolve()
    if resolved.parent != root:
        raise ConfigError("Agent configuration inbox must be inside the application state directory")
    if not resolved.name.startswith(".agent-config-") or resolved.suffix != ".json":
        raise ConfigError("Agent configuration inbox has an invalid name")
    return resolved


def _agent_file_setup(
    value: Path, *, section: str = "full", json_output: bool = False
) -> int:
    try:
        inbox = _scoped_agent_file(value)
    except (ConfigError, OSError) as exc:
        print(dump(failure(exc))) if json_output else logging.error("Cannot use Agent configuration inbox: %s", exc)
        return 1
    try:
        if os.name != "nt":
            inbox.chmod(stat.S_IRUSR | stat.S_IWUSR)
        flags = os.O_RDONLY
        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW
        descriptor = os.open(inbox, flags)
        with os.fdopen(descriptor, "r", encoding="utf-8") as handle:
            raw = handle.read(MAX_AGENT_INPUT_BYTES + 1)
    except (OSError, UnicodeError) as exc:
        try:
            inbox.unlink(missing_ok=True)
        except OSError:
            pass
        print(dump(failure(exc, message="cannot read Agent configuration inbox"))) if json_output else logging.error("Cannot read Agent configuration inbox: %s", exc)
        return 1
    try:
        inbox.unlink(missing_ok=True)
    except OSError as exc:
        print(dump(failure(exc, message="cannot remove consumed Agent configuration inbox"))) if json_output else logging.error("Cannot remove consumed Agent configuration inbox: %s", exc)
        return 1
    return _save_agent_raw(raw, section=section, json_output=json_output)


def _prompt_number(label: str, default: float, minimum: float, maximum: float) -> float:
    while True:
        raw = input(f"{label} [{default}]: ").strip()
        try:
            value = float(raw) if raw else float(default)
        except ValueError:
            print("Enter a number")
            continue
        if minimum <= value <= maximum:
            return value
        print(f"Enter a value between {minimum} and {maximum}")


def _interactive_setup() -> int:
    print("WeChat Article Subscriber — local setup")
    print("Credentials are entered locally and are not sent to an AI conversation.")
    print(
        "Sign in at https://mp.weixin.qq.com/. Open browser developer tools > "
        "Network, refresh, and select an authenticated /cgi-bin/ request. Copy the "
        "complete Cookie request header and numeric token query parameter from that "
        "same request (never /wxamp/)."
    )
    print(
        "Do not assemble selected Cookie keys. The complete header should commonly "
        "include rand_info and slave_bizuin; session keys may include slave_sid, "
        "slave_user, bizuin/data_bizuin, and data_ticket."
    )
    cookie = getpass.getpass("WeChat Cookie (hidden): ").strip()
    token = getpass.getpass("WeChat token (hidden): ").strip()
    if not cookie or not token:
        print("Cookie and token are required")
        return 1
    subscriptions = []
    print("Add exact account names and/or WeChat aliases. Blank name finishes the list.")
    while True:
        name = input("Account name: ").strip()
        if not name:
            if subscriptions:
                break
            print("Add at least one account")
            continue
        alias = input("WeChat alias (recommended, optional): ").strip()
        subscriptions.append({"name": name, "alias": alias})
    _warn_credential_shape(cookie, token)
    print("Feishu is configured later through the Agent conversation and is disabled for now.")
    check_hours = _prompt_number("Lookback hours", 24, 1, 8760)
    request_delay = _prompt_number("Request delay seconds", 3, 0, 60)
    min_score = _prompt_number("Minimum Feishu score", 6, 1, 10)
    config = {
        **DEFAULT_CONFIG,
        "wechat": {"cookie": cookie, "token": token},
        "subscriptions": subscriptions,
        "feishu": deepcopy(DEFAULT_CONFIG["feishu"]),
        "settings": {
            **DEFAULT_CONFIG["settings"],
            "check_hours": check_hours,
            "request_delay": request_delay,
            "min_score": min_score,
        },
        "setup": {"search_window_confirmed": True},
    }
    try:
        path = save_config(config)
    except (ConfigError, OSError) as exc:
        logging.error("%s", exc)
        return 1
    print(f"Configuration saved with restricted permissions: {path}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--section",
        choices=("full", "wechat", "subscriptions", "settings", "feishu"),
        default="full",
        help="configuration section for --agent-stdin/--agent-file",
    )
    parser.add_argument("--format", choices=("text", "json"), default="text")
    sources = parser.add_mutually_exclusive_group()
    sources.add_argument(
        "--guide",
        action="store_true",
        help="print secret-free dialogue setup guidance without changing configuration",
    )
    sources.add_argument(
        "--agent-stdin",
        action="store_true",
        help="read a bounded Agent configuration JSON object from standard input",
    )
    sources.add_argument(
        "--feishu-agent-stdin",
        action="store_true",
        help="merge a bounded Feishu configuration JSON object from standard input",
    )
    sources.add_argument(
        "--prepare-agent-file",
        action="store_true",
        help="create a restricted one-time inbox for Agents without standard input",
    )
    sources.add_argument(
        "--agent-file",
        type=Path,
        help="consume and delete a prepared one-time Agent configuration inbox",
    )
    sources.add_argument(
        "--feishu-agent-file",
        type=Path,
        help="merge and delete a prepared one-time Feishu configuration inbox",
    )
    arguments = parser.parse_args(argv)
    json_output = arguments.format == "json"
    if arguments.guide:
        guide = setup_guide()
        if json_output:
            print(dump(success(guide, next_action="collect_wechat_credentials")))
        else:
            print(json.dumps(guide, ensure_ascii=False, indent=2))
        return 0
    if arguments.agent_stdin:
        return _agent_stdin_setup(section=arguments.section, json_output=json_output)
    if arguments.feishu_agent_stdin:
        return _agent_stdin_setup(section="feishu", json_output=json_output)
    if arguments.prepare_agent_file:
        return _prepare_agent_file(json_output=json_output)
    if arguments.agent_file:
        return _agent_file_setup(
            arguments.agent_file, section=arguments.section, json_output=json_output
        )
    if arguments.feishu_agent_file:
        return _agent_file_setup(
            arguments.feishu_agent_file, section="feishu", json_output=json_output
        )
    return _interactive_setup()


if __name__ == "__main__":
    raise SystemExit(main())
