"""Concurrent-safe local article queue with stable URL identities."""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
import urllib.parse
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from paths import lock_path, queue_path, secure_write_json


QUEUE_VERSION = 1
MAX_PROCESSED_AGE_DAYS = 365


def empty_queue() -> dict[str, Any]:
    return {"version": QUEUE_VERSION, "pending": [], "processed": {}}


def normalize_url(url: str) -> str:
    """Normalize a URL without collapsing distinct WeChat articles."""
    if not isinstance(url, str) or not url.strip():
        raise ValueError("article URL must be a non-empty string")
    parsed = urllib.parse.urlsplit(url.strip())
    scheme = parsed.scheme.lower()
    host = (parsed.hostname or "").lower()
    if scheme not in {"http", "https"} or not host:
        raise ValueError("article URL must use http or https")
    port = parsed.port
    netloc = host if port is None else f"{host}:{port}"
    path = re.sub(r"/{2,}", "/", parsed.path or "/").rstrip("/") or "/"
    if host == "mp.weixin.qq.com" and path in {"/s", "/s/"}:
        params = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        ordered = []
        for key in ("__biz", "mid", "sn", "idx"):
            if key in params and params[key]:
                ordered.append((key, params[key][0]))
        query = urllib.parse.urlencode(ordered)
    elif host == "mp.weixin.qq.com" and path.startswith("/s/"):
        query = ""
    else:
        query = ""
    return urllib.parse.urlunsplit((scheme, netloc, path, query, ""))


def content_hash(article: dict[str, Any]) -> str | None:
    """Return a conservative secondary identity or None.

    A title/account pair is not unique: publishers routinely reuse titles and
    omit digests. Only produce a secondary identity when all content signals and
    a publication timestamp are present. Normalized URL remains authoritative.
    """
    values = [
        str(article.get(key, "")).strip()
        for key in ("title", "digest", "account", "update_time")
    ]
    if not all(values) or values[3] in {"0", "None"}:
        return None
    return hashlib.sha256("|".join(values).encode("utf-8")).hexdigest()


@contextmanager
def queue_lock(timeout: float = 10.0) -> Iterator[None]:
    """Acquire a cross-platform process lock for queue transactions."""
    path = lock_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("a+b")
    deadline = time.monotonic() + timeout
    acquired = False
    try:
        while not acquired:
            try:
                if os.name == "nt":
                    import msvcrt

                    handle.seek(0)
                    if handle.tell() == 0:
                        handle.write(b"0")
                        handle.flush()
                    handle.seek(0)
                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                acquired = True
            except (BlockingIOError, OSError):
                if time.monotonic() >= deadline:
                    raise TimeoutError(f"timed out waiting for queue lock {path}")
                time.sleep(0.05)
        yield
    finally:
        if acquired:
            if os.name == "nt":
                import msvcrt

                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        handle.close()


def _validate_queue(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("queue root must be an object")
    pending = data.get("pending")
    processed = data.get("processed")
    if not isinstance(pending, list) or not isinstance(processed, dict):
        raise ValueError("queue must contain pending list and processed object")
    for index, article in enumerate(pending):
        _validate_article(article, f"pending[{index}]")
        normalized = article.get("normalized_url")
        if not isinstance(normalized, str) or not normalized:
            raise ValueError(f"pending[{index}].normalized_url must be a non-empty string")
        if normalize_url(article["link"]) != normalized:
            raise ValueError(f"pending[{index}].normalized_url does not match link")
    for normalized, entry in processed.items():
        if not isinstance(normalized, str) or not normalized:
            raise ValueError("processed keys must be non-empty normalized URLs")
        if not isinstance(entry, dict):
            raise ValueError(f"processed[{normalized!r}] must be an object")
        article = entry.get("article")
        _validate_article(article, f"processed[{normalized!r}].article")
        if normalize_url(article["link"]) != normalized:
            raise ValueError(f"processed[{normalized!r}] key does not match article link")
        if not isinstance(entry.get("metadata"), dict):
            raise ValueError(f"processed[{normalized!r}].metadata must be an object")
        if not isinstance(entry.get("processed_at"), str):
            raise ValueError(f"processed[{normalized!r}].processed_at must be a string")
        if not isinstance(entry.get("sync_status"), str):
            raise ValueError(f"processed[{normalized!r}].sync_status must be a string")
    return {"version": QUEUE_VERSION, "pending": pending, "processed": processed}


def _validate_article(article: Any, location: str) -> None:
    if not isinstance(article, dict):
        raise ValueError(f"{location} must be an object")
    link = article.get("link")
    if not isinstance(link, str) or not link.strip():
        raise ValueError(f"{location}.link must be a non-empty string")
    normalize_url(link)
    for key in ("title", "digest", "account"):
        if key in article and not isinstance(article[key], str):
            raise ValueError(f"{location}.{key} must be a string")
    for key in ("id", "normalized_url", "content_hash", "discovered_at"):
        if key in article and article[key] is not None and not isinstance(article[key], str):
            raise ValueError(f"{location}.{key} must be a string")


def _read_unlocked() -> dict[str, Any]:
    path = queue_path()
    if not path.exists():
        return empty_queue()
    try:
        return _validate_queue(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        quarantine = path.with_name(f"queue.corrupt.{timestamp}.json")
        try:
            os.replace(path, quarantine)
        except OSError:
            pass
        raise ValueError(f"queue is invalid; preserved as {quarantine}: {exc}") from exc


def _write_unlocked(data: dict[str, Any]) -> None:
    secure_write_json(queue_path(), _validate_queue(data))


def read_queue() -> dict[str, Any]:
    with queue_lock():
        return deepcopy(_read_unlocked())


def get_pending() -> list[dict[str, Any]]:
    return read_queue()["pending"]


def add_pending(articles: list[dict[str, Any]], *, content_dedup: bool = False) -> int:
    """Add articles in one locked transaction and apply normalized URL dedup."""
    with queue_lock():
        data = _read_unlocked()
        existing_urls = set(data["processed"])
        existing_urls.update(item["normalized_url"] for item in data["pending"])
        hashes = {
            item.get("content_hash")
            for item in data["pending"]
            if item.get("content_hash")
        }
        hashes.update(
            entry.get("content_hash")
            for entry in data["processed"].values()
            if isinstance(entry, dict) and entry.get("content_hash")
        )
        added = 0
        for source in articles:
            article = deepcopy(source)
            normalized = normalize_url(str(article.get("link", "")))
            digest = content_hash(article)
            if normalized in existing_urls or (content_dedup and digest in hashes):
                continue
            article["id"] = hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]
            article["normalized_url"] = normalized
            if digest:
                article["content_hash"] = digest
            article["discovered_at"] = datetime.now(timezone.utc).isoformat()
            data["pending"].append(article)
            existing_urls.add(normalized)
            if digest:
                hashes.add(digest)
            added += 1
        _write_unlocked(data)
        return added


def resolve_pending(*, index: int | None = None, link: str | None = None) -> dict[str, Any]:
    pending = get_pending()
    if link:
        normalized = normalize_url(link)
        for article in pending:
            if article.get("normalized_url") == normalized:
                return article
        raise LookupError("no pending article matches that URL")
    if index is None or index < 0 or index >= len(pending):
        raise LookupError(f"article index must be between 1 and {len(pending)}")
    return pending[index]


def complete_article(
    link: str,
    metadata: dict[str, Any] | None = None,
    *,
    sync_status: str = "not_requested",
) -> dict[str, Any]:
    """Move one article to processed using its stable normalized URL."""
    normalized = normalize_url(link)
    with queue_lock():
        data = _read_unlocked()
        article = next(
            (item for item in data["pending"] if item.get("normalized_url") == normalized),
            None,
        )
        if article is None:
            existing = data["processed"].get(normalized)
            if existing:
                return deepcopy(existing)
            raise LookupError("article is no longer pending")
        data["pending"] = [
            item for item in data["pending"] if item.get("normalized_url") != normalized
        ]
        entry = {
            "article": deepcopy(article),
            "content_hash": article.get("content_hash"),
            "processed_at": datetime.now(timezone.utc).isoformat(),
            "sync_status": sync_status,
            "metadata": deepcopy(metadata or {}),
        }
        data["processed"][normalized] = entry
        _write_unlocked(data)
        return deepcopy(entry)


def update_sync_status(link: str, status: str, error: str = "") -> None:
    normalized = normalize_url(link)
    with queue_lock():
        data = _read_unlocked()
        entry = data["processed"].get(normalized)
        if not entry:
            raise LookupError("processed article not found")
        entry["sync_status"] = status
        entry["sync_updated_at"] = datetime.now(timezone.utc).isoformat()
        if error:
            entry["sync_error"] = error[:500]
        else:
            entry.pop("sync_error", None)
        _write_unlocked(data)


def pending_sync_entries() -> list[dict[str, Any]]:
    data = read_queue()
    return [
        deepcopy(entry)
        for entry in data["processed"].values()
        if isinstance(entry, dict) and entry.get("sync_status") == "pending"
    ]


def cleanup_processed(max_age_days: int = MAX_PROCESSED_AGE_DAYS) -> int:
    if max_age_days < 1:
        raise ValueError("max_age_days must be positive")
    cutoff = time.time() - max_age_days * 86400
    with queue_lock():
        data = _read_unlocked()
        before = len(data["processed"])
        retained = {}
        for link, entry in data["processed"].items():
            if entry.get("sync_status") == "pending":
                retained[link] = entry
                continue
            try:
                timestamp = datetime.fromisoformat(entry["processed_at"]).timestamp()
            except (KeyError, TypeError, ValueError):
                retained[link] = entry
                continue
            if timestamp >= cutoff:
                retained[link] = entry
        data["processed"] = retained
        _write_unlocked(data)
        return before - len(retained)


def export_queue(path: Path) -> Path:
    secure_write_json(Path(path), read_queue())
    return Path(path)
