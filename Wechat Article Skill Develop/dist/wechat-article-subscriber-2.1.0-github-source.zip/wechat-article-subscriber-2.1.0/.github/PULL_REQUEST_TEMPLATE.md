## Description

Describe the change and the problem it solves.

## Type of Change

- [ ] Bug fix
- [ ] New feature
- [ ] Documentation update
- [ ] Refactor / performance improvement

## Checklist

- [ ] I have read the CONTRIBUTING document
- [ ] My code follows coding standards (PEP 8, type hints)
- [ ] I have added or updated tests
- [ ] All tests pass
- [ ] I have updated documentation
- [ ] My changes generate no new warnings
