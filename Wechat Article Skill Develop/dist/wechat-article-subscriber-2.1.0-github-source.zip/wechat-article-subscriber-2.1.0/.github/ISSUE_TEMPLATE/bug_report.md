---
name: Bug report
about: Create a report to help us improve
title: "[BUG] "
labels: bug

---

## Describe the Bug

## To Reproduce

## Expected Behavior

## Environment

- OS:
- Python version:
- lark-cli version (if used):

## Additional Context
