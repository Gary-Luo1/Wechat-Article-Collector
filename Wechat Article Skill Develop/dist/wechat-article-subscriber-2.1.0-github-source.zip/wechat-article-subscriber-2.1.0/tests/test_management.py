from __future__ import annotations

import io
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest


ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "skills" / "wechat-article-subscriber" / "scripts"


@pytest.fixture(autouse=True)
def isolated_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("WECHAT_ARTICLE_HOME", str(tmp_path / "state"))


def configured() -> dict:
    from config_store import DEFAULT_CONFIG, save_config

    config = json.loads(json.dumps(DEFAULT_CONFIG))
    config["wechat"] = {"cookie": "cookie-secret", "token": "token-secret"}
    config["subscriptions"] = [{"name": "Example"}]
    save_config(config)
    return config


def test_partial_settings_patch_preserves_other_values(monkeypatch: pytest.MonkeyPatch):
    import init_config
    from config_store import load_config

    configured()
    monkeypatch.setattr(init_config.sys, "stdin", io.StringIO('{"output_language":"zh"}'))
    assert init_config.main(["--agent-stdin", "--section", "settings", "--format", "json"]) == 0
    saved = load_config()
    assert saved["settings"]["output_language"] == "zh"
    assert saved["settings"]["check_hours"] == 24
    assert saved["setup"]["search_window_confirmed"] is False


def test_check_hours_patch_confirms_search_window(monkeypatch: pytest.MonkeyPatch, capsys):
    import init_config
    from config_store import load_config

    configured()
    monkeypatch.setattr(init_config.sys, "stdin", io.StringIO('{"check_hours":168}'))
    assert init_config.main(
        ["--agent-stdin", "--section", "settings", "--format", "json"]
    ) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["next_action"] == "run_doctor_online"
    assert load_config()["setup"]["search_window_confirmed"] is True


def test_setup_guide_explains_input_cookie_token_and_search_window(capsys):
    import init_config

    assert init_config.main(["--guide", "--format", "json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    data = payload["data"]
    assert data["input_location"]["preferred"]
    assert data["wechat_credentials"]["login_url"] == "https://mp.weixin.qq.com/"
    assert data["wechat_credentials"]["cookie_rule"].startswith("copy the complete")
    assert data["wechat_credentials"]["cookie_diagnostic_keys"] == [
        "rand_info",
        "slave_bizuin",
    ]
    assert data["search_window"]["default_if_skipped"] == 24
    assert "cgi-bin/home?t=home/index" not in json.dumps(data)


def test_config_migration_is_versioned_and_backed_up(tmp_path: Path):
    from config_store import CONFIG_VERSION, ConfigError, load_config, save_config
    from paths import config_path

    target = config_path()
    target.parent.mkdir(parents=True)
    target.write_text(
        json.dumps({
            "version": 1,
            "wechat": {"cookie": "old", "token": "1"},
            "subscriptions": [{"name": "Example"}],
        }),
        encoding="utf-8",
    )
    save_config(load_config())
    assert (target.parent / "config.v1.backup.json").is_file()
    assert load_config()["version"] == CONFIG_VERSION
    future = json.loads(target.read_text(encoding="utf-8"))
    future["version"] = CONFIG_VERSION + 1
    target.write_text(json.dumps(future), encoding="utf-8")
    with pytest.raises(ConfigError):
        load_config()


def test_doctor_is_redacted_and_resumable(monkeypatch: pytest.MonkeyPatch, capsys):
    import manage

    configured()
    monkeypatch.setattr(
        manage,
        "lark_cli_info",
        lambda: {"path": "lark-cli", "version": "1.0.69", "tested_version": "1.0.69", "compatible": True},
    )
    assert manage.main(["doctor"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["ok"] is True
    rendered = json.dumps(payload)
    assert "cookie-secret" not in rendered
    assert "token-secret" not in rendered
    assert payload["data"]["setup_stage"] == "wechat_unverified"
    assert payload["next_action"] == "run_online_doctor"


def test_doctor_pauses_for_unconfirmed_search_window(
    monkeypatch: pytest.MonkeyPatch, capsys
):
    import manage
    from config_store import load_config, save_config

    configured()
    config = load_config()
    config["health"]["wechat"]["last_verified_at"] = "2026-01-01T00:00:00+00:00"
    save_config(config)
    monkeypatch.setattr(
        manage,
        "lark_cli_info",
        lambda: {"compatible": True, "version": "1.0.69"},
    )
    assert manage.main(["doctor"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["data"]["setup_stage"] == "search_window_unconfirmed"
    assert payload["next_action"] == "ask_user_for_search_window"


def test_feishu_context_never_guesses_generic_agent_bot(
    monkeypatch: pytest.MonkeyPatch, capsys
):
    import manage
    from config_store import load_config, save_config

    configured()
    config = load_config()
    config["feishu"]["binding_mode"] = "agent"
    config["feishu"]["agent_source"] = "openclaw"
    save_config(config)
    monkeypatch.setattr(
        manage,
        "feishu_identity_context",
        lambda verify=False: {
            "app_id": "cli_verified",
            "app_ids": ["cli_verified"],
            "app_id_unambiguous": True,
            "user": {"available": True, "status": "ready", "open_id": "ou_user"},
        },
    )
    for name in (
        "OPENCLAW_HOME",
        "OPENCLAW_STATE_DIR",
        "OPENCLAW_GATEWAY_TOKEN",
        "HERMES_HOME",
        "HERMES_STATE_DIR",
        "LARK_CHANNEL",
        "LARK_CHANNEL_HOME",
        "LARK_CHANNEL_APP_ID",
    ):
        monkeypatch.delenv(name, raising=False)
    assert manage.main(["feishu-context", "--verify"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["data"]["can_bind_current_agent"] is False
    assert payload["data"]["agent_source_configured"] == "openclaw"
    assert "generic" in payload["data"]["binding_modes"]["dedicated"]
    assert payload["next_action"] == "confirm_feishu_app_and_user"


def test_reset_previews_then_clears_credentials(capsys):
    import manage
    from config_store import load_config

    configured()
    assert manage.main(["reset", "--scope", "credentials"]) == 0
    preview = json.loads(capsys.readouterr().out)
    assert preview["next_action"] == "rerun_with_yes"
    assert load_config()["wechat"]["cookie"] == "cookie-secret"
    assert manage.main(["reset", "--scope", "credentials", "--yes"]) == 0
    capsys.readouterr()
    saved = load_config()
    assert saved["wechat"] == {"cookie": "", "token": ""}
    assert saved["subscriptions"] == [{"name": "Example"}]


def test_subscription_resolution_reports_ambiguity_without_guessing():
    from discover_only import resolve_subscriptions

    config = configured()

    class API:
        def search_account(self, query, count=5):
            return [
                {"nickname": "Example A", "alias": "example", "fakeid": "biz-a"},
                {"nickname": "Example B", "alias": "example", "fakeid": "biz-b"},
            ]

    config["subscriptions"] = [{"alias": "example"}]
    result = resolve_subscriptions(config, api=API(), save=False)
    assert result[0]["status"] == "ambiguous"
    assert "biz" not in config["subscriptions"][0]


def test_process_json_failure_is_structured(capsys):
    import process_pending

    assert process_pending.main(["--format", "json", "read", "1"]) == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "ARTICLE_NOT_FOUND"


def _direct_article(account: str = "New Account") -> dict:
    return {
        "title": "Direct article",
        "account": account,
        "account_id": "biz-direct",
        "digest": "Direct digest",
        "update_time": 1_700_000_000,
        "link": "https://mp.weixin.qq.com/s/direct",
        "text": "Untrusted body",
    }


def test_ingest_unlisted_publisher_requires_question_before_mutation(
    monkeypatch: pytest.MonkeyPatch, capsys
):
    import process_pending
    from config_store import load_config
    from queue_helpers import get_pending

    configured()
    monkeypatch.setattr(process_pending, "fetch_article", lambda url: _direct_article())
    assert process_pending.main(
        ["--format", "json", "ingest", "--url", _direct_article()["link"]]
    ) == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["error"]["code"] == "SUBSCRIPTION_CONFIRMATION_REQUIRED"
    assert payload["error"]["details"]["account"] == "New Account"
    assert get_pending() == []
    assert load_config()["subscriptions"] == [{"name": "Example"}]


def test_ingest_adds_subscription_only_after_explicit_consent(
    monkeypatch: pytest.MonkeyPatch, capsys
):
    import process_pending
    from config_store import load_config
    from queue_helpers import get_pending

    configured()
    monkeypatch.setattr(process_pending, "fetch_article", lambda url: _direct_article())
    assert process_pending.main(
        [
            "--format",
            "json",
            "ingest",
            "--url",
            _direct_article()["link"],
            "--subscribe",
        ]
    ) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["data"]["queued"] is True
    assert payload["data"]["publisher"]["subscription_added"] is True
    assert load_config()["subscriptions"][-1] == {
        "name": "New Account",
        "biz": "biz-direct",
    }
    assert get_pending()[0]["account"] == "New Account"
    assert "text" not in get_pending()[0]


def test_ingest_once_does_not_change_subscriptions(
    monkeypatch: pytest.MonkeyPatch, capsys
):
    import process_pending
    from config_store import load_config
    from queue_helpers import get_pending

    configured()
    monkeypatch.setattr(process_pending, "fetch_article", lambda url: _direct_article())
    assert process_pending.main(
        [
            "--format",
            "json",
            "ingest",
            "--url",
            _direct_article()["link"],
            "--no-subscribe",
        ]
    ) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["data"]["publisher"]["subscribed"] is False
    assert load_config()["subscriptions"] == [{"name": "Example"}]
    assert len(get_pending()) == 1


def test_ingest_unknown_publisher_requests_name_and_choice(
    monkeypatch: pytest.MonkeyPatch, capsys
):
    import process_pending

    configured()
    monkeypatch.setattr(
        process_pending,
        "fetch_article",
        lambda url: {**_direct_article(""), "account_id": ""},
    )
    assert process_pending.main(
        ["--format", "json", "ingest", "--url", _direct_article()["link"]]
    ) == 1
    payload = json.loads(capsys.readouterr().out)
    assert payload["error"]["code"] == "ARTICLE_PUBLISHER_UNKNOWN"


def test_ingest_existing_subscription_is_immediate_and_idempotent(
    monkeypatch: pytest.MonkeyPatch, capsys
):
    import process_pending
    from queue_helpers import get_pending

    configured()
    document = _direct_article("Example")
    document["account_id"] = ""
    monkeypatch.setattr(process_pending, "fetch_article", lambda url: document)
    command = ["--format", "json", "ingest", "--url", document["link"]]
    assert process_pending.main(command) == 0
    first = json.loads(capsys.readouterr().out)
    assert first["data"]["status"] == "queued"
    assert process_pending.main(command) == 0
    second = json.loads(capsys.readouterr().out)
    assert second["data"]["status"] == "already_known"
    assert len(get_pending()) == 1


def test_lark_cli_version_range_is_reported(monkeypatch: pytest.MonkeyPatch):
    import bitable_client

    monkeypatch.setattr(bitable_client, "_lark_cli", lambda: "lark-cli")
    monkeypatch.setattr(
        bitable_client.subprocess,
        "run",
        lambda *args, **kwargs: type("Result", (), {"returncode": 0, "stdout": "lark-cli 2.0.0", "stderr": ""})(),
    )
    info = bitable_client.lark_cli_info()
    assert info["version"] == "2.0.0"
    assert info["compatible"] is False


@pytest.mark.skipif(os.name != "nt", reason="Windows custom installer test")
def test_windows_custom_install_path(tmp_path: Path):
    powershell = "powershell"
    destination = tmp_path / "custom" / "wechat-article-subscriber"
    result = subprocess.run(
        [
            powershell,
            "-NoLogo",
            "-NoProfile",
            "-File",
            str(ROOT / "install.ps1"),
            "-Target",
            "agents",
            "-InstallPath",
            str(destination),
            "-NoDeps",
        ],
        cwd=ROOT,
        check=False,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    assert result.returncode == 0, result.stderr
    assert (destination / "SKILL.md").is_file()
